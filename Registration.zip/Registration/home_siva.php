<!DOCTYPE html>
<html lang="en">

<head>
    <title>Big Tree</title>
    <meta charset="UTF-8">
</head>

<body>

    <h1> home Page </h1>
	WELCOME

</body>

</html>